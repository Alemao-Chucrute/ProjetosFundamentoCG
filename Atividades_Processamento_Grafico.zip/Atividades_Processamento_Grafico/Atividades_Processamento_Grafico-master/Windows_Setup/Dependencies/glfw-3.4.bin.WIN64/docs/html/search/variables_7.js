var searchData=
[
  ['size_0',['size',['../struct_g_l_f_wgammaramp.html#ad620e1cffbff9a32c51bca46301b59a5',1,'GLFWgammaramp']]]
];
