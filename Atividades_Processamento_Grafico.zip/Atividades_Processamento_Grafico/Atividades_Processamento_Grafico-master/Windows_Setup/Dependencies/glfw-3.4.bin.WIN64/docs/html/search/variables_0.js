var searchData=
[
  ['allocate_0',['allocate',['../struct_g_l_f_wallocator.html#a18a798136f17a9cb105be18312193bf7',1,'GLFWallocator']]],
  ['axes_1',['axes',['../struct_g_l_f_wgamepadstate.html#a8b2c8939b1d31458de5359998375c189',1,'GLFWgamepadstate']]]
];
